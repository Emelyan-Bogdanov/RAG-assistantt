"""
rag/embeddings/models.py
------------------------
BERT-based text classifier: professional vs. non-professional tone.

As described in the internship report, BERT (Bidirectional Encoder
Representations from Transformers) is fine-tuned on labelled examples
to classify whether a chunk of text is written in a professional register.

This is used optionally in the ingestion pipeline to filter out low-quality
or informal content before it is stored in the vector database.
"""

from __future__ import annotations

import os
from typing import List, Tuple

import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset
from transformers import BertForSequenceClassification, BertTokenizer


# ── Dataset ──────────────────────────────────────────────────────────────────

class TextDataset(Dataset):
    """
    Minimal dataset wrapper for tokenised BERT inputs.

    labels: 1 = professional, 0 = non-professional
    """

    def __init__(self, texts: List[str], labels: List[int], tokenizer, max_length: int = 128):
        self.encodings = tokenizer(
            texts,
            truncation=True,
            padding=True,
            max_length=max_length,
            return_tensors="pt",
        )
        self.labels = torch.tensor(labels, dtype=torch.long)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return {key: val[idx] for key, val in self.encodings.items()}, self.labels[idx]


# ── Classifier ───────────────────────────────────────────────────────────────

class ProfessionalityClassifier:
    """
    Fine-tunes and runs BERT for binary text classification.

    Usage
    -----
    clf = ProfessionalityClassifier()
    clf.train(train_texts, train_labels, epochs=3)
    result = clf.predict("This quarterly report demonstrates strong KPIs.")
    # → ("professional", 0.97)
    """

    LABELS = {0: "non-professional", 1: "professional"}
    MODEL_NAME = "bert-base-uncased"

    def __init__(self, model_path: str | None = None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = BertTokenizer.from_pretrained(self.MODEL_NAME)

        if model_path and os.path.exists(model_path):
            self.model = BertForSequenceClassification.from_pretrained(model_path)
            print(f"[BERT] Loaded fine-tuned model from {model_path}")
        else:
            self.model = BertForSequenceClassification.from_pretrained(
                self.MODEL_NAME, num_labels=2
            )
            print("[BERT] Loaded base model (not yet fine-tuned)")

        self.model.to(self.device)

    # ── training ─────────────────────────────────────────────────────────────

    def train(
        self,
        texts: List[str],
        labels: List[int],
        epochs: int = 3,
        batch_size: int = 16,
        lr: float = 2e-5,
    ) -> None:
        """Fine-tune BERT on (texts, labels) pairs."""
        dataset = TextDataset(texts, labels, self.tokenizer)
        loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
        optimizer = torch.optim.AdamW(self.model.parameters(), lr=lr)
        loss_fn = nn.CrossEntropyLoss()

        self.model.train()
        for epoch in range(epochs):
            total_loss = 0.0
            for batch_inputs, batch_labels in loader:
                batch_inputs = {k: v.to(self.device) for k, v in batch_inputs.items()}
                batch_labels = batch_labels.to(self.device)

                optimizer.zero_grad()
                outputs = self.model(**batch_inputs)
                loss = loss_fn(outputs.logits, batch_labels)
                loss.backward()
                optimizer.step()
                total_loss += loss.item()

            avg = total_loss / len(loader)
            print(f"[BERT] Epoch {epoch + 1}/{epochs}  loss={avg:.4f}")

    def save(self, path: str) -> None:
        self.model.save_pretrained(path)
        self.tokenizer.save_pretrained(path)
        print(f"[BERT] Model saved to {path}")

    # ── inference ────────────────────────────────────────────────────────────

    def predict(self, text: str) -> Tuple[str, float]:
        """Return (label_string, probability) for a single text."""
        self.model.eval()
        encoding = self.tokenizer(
            text,
            truncation=True,
            padding=True,
            max_length=128,
            return_tensors="pt",
        ).to(self.device)

        with torch.no_grad():
            logits = self.model(**encoding).logits

        probs = torch.softmax(logits, dim=-1).squeeze()
        pred_idx = int(torch.argmax(probs).item())
        return self.LABELS[pred_idx], float(probs[pred_idx].item())

    def is_professional(self, text: str, threshold: float = 0.75) -> bool:
        label, prob = self.predict(text)
        return label == "professional" and prob >= threshold
