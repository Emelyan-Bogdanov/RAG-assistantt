"""
rag/embeddings/embedder.py
--------------------------
Converts text chunks into dense vector embeddings.

Primary model : sentence-transformers/all-MiniLM-L6-v2
                (fast, 384-dim, good semantic quality)

The embedder is also used at query time to embed the user's question
before similarity search.
"""

from __future__ import annotations

import os
from typing import List

import numpy as np
from sentence_transformers import SentenceTransformer
from tqdm import tqdm

from rag.ingestion.splitter import Chunk


class Embedder:
    """
    Wraps a SentenceTransformer model to produce embeddings for chunks
    and for query strings.

    Parameters
    ----------
    model_name : HuggingFace model id (defaults to env EMBEDDING_MODEL)
    batch_size : number of texts encoded per forward pass
    """

    def __init__(
        self,
        model_name: str | None = None,
        batch_size: int = 32,
    ):
        self.model_name = model_name or os.getenv(
            "EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"
        )
        self.batch_size = batch_size
        print(f"[embedder] Loading model: {self.model_name}")
        self._model = SentenceTransformer(self.model_name)

    # ── public API ───────────────────────────────────────────────────────────

    def embed_chunks(self, chunks: List[Chunk]) -> List[np.ndarray]:
        """Return a list of embedding vectors, one per chunk."""
        texts = [c.text for c in chunks]
        return self._encode(texts)

    def embed_query(self, query: str) -> np.ndarray:
        """Return the embedding vector for a single query string."""
        return self._model.encode(query, convert_to_numpy=True, normalize_embeddings=True)

    # ── internal ─────────────────────────────────────────────────────────────

    def _encode(self, texts: List[str]) -> List[np.ndarray]:
        embeddings = []
        for i in tqdm(range(0, len(texts), self.batch_size),
                      desc="Embedding", unit="batch"):
            batch = texts[i : i + self.batch_size]
            vecs = self._model.encode(
                batch,
                convert_to_numpy=True,
                normalize_embeddings=True,
                show_progress_bar=False,
            )
            embeddings.extend(vecs)
        return embeddings
