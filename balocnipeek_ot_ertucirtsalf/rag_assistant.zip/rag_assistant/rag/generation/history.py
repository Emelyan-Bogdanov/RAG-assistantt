"""
rag/generation/history.py
-------------------------
Manages the conversational memory (chat history).

Keeps a rolling window of the last N turns so the LLM stays in context
without overflowing the token budget.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Literal


Role = Literal["user", "assistant", "system"]


@dataclass
class Message:
    role: Role
    content: str


class ChatHistory:
    """
    Stores and retrieves conversation turns.

    Parameters
    ----------
    max_turns : maximum number of (user, assistant) round-trips to keep.
                Older turns are dropped when the limit is exceeded.
    """

    def __init__(self, max_turns: int = 10):
        self.max_turns = max_turns
        self._messages: List[Message] = []

    # ── write ────────────────────────────────────────────────────────────────

    def add_user(self, text: str) -> None:
        self._messages.append(Message(role="user", content=text))
        self._trim()

    def add_assistant(self, text: str) -> None:
        self._messages.append(Message(role="assistant", content=text))
        self._trim()

    def clear(self) -> None:
        self._messages.clear()

    # ── read ─────────────────────────────────────────────────────────────────

    @property
    def messages(self) -> List[Message]:
        return list(self._messages)

    def to_openai_format(self) -> List[dict]:
        """Convert to the list-of-dicts format expected by openai.chat.completions."""
        return [{"role": m.role, "content": m.content} for m in self._messages]

    def to_text(self, user_prefix: str = "User", ai_prefix: str = "Assistant") -> str:
        """Return history as a plain-text transcript."""
        lines = []
        for m in self._messages:
            prefix = user_prefix if m.role == "user" else ai_prefix
            lines.append(f"{prefix}: {m.content}")
        return "\n".join(lines)

    def __len__(self) -> int:
        return len(self._messages)

    # ── internal ─────────────────────────────────────────────────────────────

    def _trim(self) -> None:
        """Keep at most max_turns * 2 messages (user + assistant per turn)."""
        limit = self.max_turns * 2
        if len(self._messages) > limit:
            self._messages = self._messages[-limit:]
