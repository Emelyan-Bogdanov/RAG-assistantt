"""
rag/generation/generator.py
----------------------------
Sends the assembled prompt to the OpenAI API and returns the response.

Model: gpt-3.5-turbo (as specified in the internship report — good balance
of accuracy and reasoning for RAG use cases).
"""

from __future__ import annotations

import os
from typing import List

from openai import OpenAI

from rag.generation.history import ChatHistory
from rag.generation.prompt_builder import PromptBuilder


class Generator:
    """
    Wraps the OpenAI chat completions API.

    Parameters
    ----------
    model       : OpenAI model id (default: gpt-3.5-turbo)
    temperature : sampling temperature (0 = deterministic)
    max_tokens  : maximum tokens in the response
    """

    def __init__(
        self,
        model: str | None = None,
        temperature: float = 0.2,
        max_tokens: int = 1024,
    ):
        self.model = model or os.getenv("LLM_MODEL", "gpt-3.5-turbo")
        self.temperature = temperature
        self.max_tokens = max_tokens
        self._client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self._builder = PromptBuilder()

    def generate(
        self,
        query: str,
        context: str,
        history: ChatHistory | None = None,
    ) -> str:
        """
        Generate an answer for *query* given retrieved *context*.

        Parameters
        ----------
        query   : user's current question
        context : formatted string of top-K retrieved chunks
        history : optional chat history for conversational continuity
        """
        messages = self._builder.build(query=query, context=context, history=history)
        response = self._client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )
        answer = response.choices[0].message.content or ""
        return answer.strip()
