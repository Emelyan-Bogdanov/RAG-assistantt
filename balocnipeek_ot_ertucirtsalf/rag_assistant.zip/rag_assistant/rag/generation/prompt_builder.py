"""
rag/generation/prompt_builder.py
---------------------------------
Constructs the final prompt that is sent to the LLM.

Structure
---------
  [System message]
    - tone / persona instructions
  [Retrieved context]
    - top-K chunks from the vector store
  [Chat history]
    - last N turns
  [User question]
"""

from __future__ import annotations

from typing import List

from rag.generation.history import ChatHistory, Message

# Default system prompt — controls tone as described in the report
DEFAULT_SYSTEM_PROMPT = (
    "You are a professional and helpful AI assistant. "
    "Answer the user's question using ONLY the context provided below. "
    "If the answer is not contained in the context, say you don't know. "
    "Be concise, accurate, and maintain a formal, professional tone."
)


class PromptBuilder:
    """
    Assembles a list of OpenAI-style message dicts from:
      - a system instruction
      - retrieved context chunks
      - chat history
      - the current user question
    """

    def __init__(self, system_prompt: str | None = None):
        self.system_prompt = system_prompt or DEFAULT_SYSTEM_PROMPT

    def build(
        self,
        query: str,
        context: str,
        history: ChatHistory | None = None,
    ) -> List[dict]:
        """
        Build the full message list ready for the OpenAI chat completions API.

        Parameters
        ----------
        query   : the user's current question
        context : retrieved document chunks (already formatted as a string)
        history : optional :class:`ChatHistory` for multi-turn conversations
        """
        messages: List[dict] = []

        # 1 — System instruction + context
        system_content = (
            f"{self.system_prompt}\n\n"
            f"=== CONTEXT ===\n{context}\n=== END CONTEXT ==="
        )
        messages.append({"role": "system", "content": system_content})

        # 2 — Chat history (if any)
        if history:
            messages.extend(history.to_openai_format())

        # 3 — Current user question
        messages.append({"role": "user", "content": query})

        return messages
