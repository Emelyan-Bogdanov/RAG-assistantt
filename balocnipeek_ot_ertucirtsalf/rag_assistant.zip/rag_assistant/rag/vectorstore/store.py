"""
rag/vectorstore/store.py
------------------------
Persistent vector store backed by ChromaDB.

Stores embedded chunks and retrieves the top-K most similar ones
for a given query embedding.
"""

from __future__ import annotations

import os
from typing import List, Tuple

import numpy as np
import chromadb
from chromadb.config import Settings

from rag.ingestion.splitter import Chunk


class VectorStore:
    """
    Wraps a ChromaDB collection for storing and querying chunk embeddings.

    Parameters
    ----------
    persist_dir   : directory where ChromaDB persists its data
    collection    : name of the collection inside ChromaDB
    """

    def __init__(
        self,
        persist_dir: str | None = None,
        collection: str | None = None,
    ):
        self.persist_dir = persist_dir or os.getenv(
            "CHROMA_PERSIST_DIR", "./rag/vectorstore/chroma_db"
        )
        self.collection_name = collection or os.getenv(
            "CHROMA_COLLECTION_NAME", "rag_documents"
        )

        os.makedirs(self.persist_dir, exist_ok=True)
        self._client = chromadb.PersistentClient(
            path=self.persist_dir,
            settings=Settings(anonymized_telemetry=False),
        )
        self._collection = self._client.get_or_create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        print(f"[vectorstore] Collection '{self.collection_name}' "
              f"— {self._collection.count()} documents stored")

    # ── write ────────────────────────────────────────────────────────────────

    def add_chunks(self, chunks: List[Chunk], embeddings: List[np.ndarray]) -> None:
        """Persist chunks with their pre-computed embeddings."""
        if len(chunks) != len(embeddings):
            raise ValueError("chunks and embeddings must have the same length")

        ids = [f"{c.source}::{c.chunk_index}" for c in chunks]
        documents = [c.text for c in chunks]
        metadatas = [c.metadata for c in chunks]
        vectors = [e.tolist() for e in embeddings]

        # ChromaDB upsert avoids duplicate key errors on re-ingestion
        self._collection.upsert(
            ids=ids,
            documents=documents,
            metadatas=metadatas,
            embeddings=vectors,
        )
        print(f"[vectorstore] Upserted {len(chunks)} chunks")

    def clear(self) -> None:
        """Delete and recreate the collection."""
        self._client.delete_collection(self.collection_name)
        self._collection = self._client.get_or_create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        print(f"[vectorstore] Collection '{self.collection_name}' cleared")

    # ── read ─────────────────────────────────────────────────────────────────

    def query(
        self,
        query_embedding: np.ndarray,
        top_k: int | None = None,
    ) -> List[Tuple[str, dict, float]]:
        """
        Return the *top_k* most similar chunks.

        Returns a list of (document_text, metadata, distance) tuples
        sorted by ascending cosine distance (0 = identical, 2 = opposite).
        """
        k = top_k or int(os.getenv("TOP_K_RESULTS", 5))
        results = self._collection.query(
            query_embeddings=[query_embedding.tolist()],
            n_results=k,
            include=["documents", "metadatas", "distances"],
        )

        docs = results["documents"][0]
        metas = results["metadatas"][0]
        dists = results["distances"][0]
        return list(zip(docs, metas, dists))

    @property
    def count(self) -> int:
        return self._collection.count()
