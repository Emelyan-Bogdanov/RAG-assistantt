"""
rag/pipeline.py
---------------
Central orchestrator of the RAG system.

The pipeline manages two workflows:

  INGESTION  — load → clean → split → embed → store
  QUERYING   — retrieve → build prompt → generate → return answer

Usage
-----
    from rag.pipeline import RAGPipeline

    pipe = RAGPipeline()
    pipe.ingest("./data/raw")                   # index your documents once
    answer = pipe.query("What is data.gov.ma?") # ask questions any time
"""

from __future__ import annotations

import os
from typing import List

from dotenv import load_dotenv

load_dotenv()  # load .env before any other imports that read env vars

from rag.embeddings.embedder import Embedder
from rag.generation.generator import Generator
from rag.generation.history import ChatHistory
from rag.ingestion.cleaner import TextCleaner
from rag.ingestion.loader import DocumentLoader
from rag.ingestion.splitter import DocumentSplitter
from rag.retrieval.retriever import Retriever
from rag.vectorstore.store import VectorStore


class RAGPipeline:
    """
    End-to-end RAG pipeline.

    All components are instantiated once and reused across calls.
    The pipeline keeps a :class:`ChatHistory` so multi-turn conversations
    are aware of previous exchanges.

    Parameters
    ----------
    data_dir : default directory to scan for documents during ingestion
    """

    def __init__(self, data_dir: str = "./data/raw"):
        self.data_dir = data_dir

        # Shared components
        self._loader = DocumentLoader()
        self._cleaner = TextCleaner()
        self._splitter = DocumentSplitter()
        self._embedder = Embedder()
        self._store = VectorStore()
        self._retriever = Retriever(embedder=self._embedder, store=self._store)
        self._generator = Generator()
        self._history = ChatHistory(max_turns=10)

    # ── ingestion ────────────────────────────────────────────────────────────

    def ingest(self, directory: str | None = None) -> int:
        """
        Load, clean, chunk and embed all documents in *directory*.

        Returns the total number of chunks indexed.
        """
        source = directory or self.data_dir
        print(f"\n[pipeline] ── Ingestion from: {source}")

        raw_docs = self._loader.load_directory(source)
        print(f"[pipeline] Loaded {len(raw_docs)} document(s)")

        clean_docs = self._cleaner.clean_all(raw_docs)
        print(f"[pipeline] {len(clean_docs)} document(s) after cleaning")

        chunks = self._splitter.split_all(clean_docs)

        embeddings = self._embedder.embed_chunks(chunks)

        self._store.add_chunks(chunks, embeddings)
        print(f"[pipeline] Ingestion complete — {len(chunks)} chunks stored\n")
        return len(chunks)

    def ingest_files(self, file_paths: List[str]) -> int:
        """Ingest a specific list of files instead of a whole directory."""
        raw_docs = self._loader.load_files(file_paths)
        clean_docs = self._cleaner.clean_all(raw_docs)
        chunks = self._splitter.split_all(clean_docs)
        embeddings = self._embedder.embed_chunks(chunks)
        self._store.add_chunks(chunks, embeddings)
        return len(chunks)

    # ── querying ─────────────────────────────────────────────────────────────

    def query(self, question: str, top_k: int | None = None) -> str:
        """
        Answer *question* using the indexed documents and chat history.

        Steps:
          1. Embed the question
          2. Retrieve top-K similar chunks from ChromaDB
          3. Build the prompt (system + context + history + question)
          4. Call the LLM
          5. Update chat history
          6. Return the answer string
        """
        print(f"[pipeline] Query: {question!r}")

        context = self._retriever.retrieve_as_context(question, top_k=top_k)
        answer = self._generator.generate(
            query=question,
            context=context,
            history=self._history,
        )

        # Update conversational memory
        self._history.add_user(question)
        self._history.add_assistant(answer)

        return answer

    # ── helpers ──────────────────────────────────────────────────────────────

    def reset_history(self) -> None:
        """Clear the chat history (start a new conversation)."""
        self._history.clear()

    @property
    def indexed_count(self) -> int:
        """Number of chunks currently in the vector store."""
        return self._store.count
