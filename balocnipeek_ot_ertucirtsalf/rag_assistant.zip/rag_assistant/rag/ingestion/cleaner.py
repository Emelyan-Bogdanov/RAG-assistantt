"""
rag/ingestion/cleaner.py
------------------------
Cleans raw extracted text before it is chunked and embedded.

Operations applied (in order):
  1. Remove null bytes and control characters
  2. Normalise Unicode (NFC)
  3. Collapse excessive whitespace / blank lines
  4. Strip headers / footers heuristics (page numbers, repeated lines)
  5. (Optional) Detect and discard non-professional text via BERT classifier
"""

from __future__ import annotations

import re
import unicodedata
from typing import List

from rag.ingestion.loader import RawDocument


class TextCleaner:
    """
    Cleans the `content` field of :class:`RawDocument` objects in-place.
    Returns a new list of :class:`RawDocument` with cleaned content.
    """

    def clean_all(self, docs: List[RawDocument]) -> List[RawDocument]:
        cleaned = []
        for doc in docs:
            text = self._clean(doc.content)
            if text:  # discard empty documents after cleaning
                cleaned.append(RawDocument(
                    source=doc.source,
                    content=text,
                    metadata=doc.metadata,
                ))
        return cleaned

    def clean(self, text: str) -> str:
        return self._clean(text)

    # ── private ──────────────────────────────────────────────────────────────

    def _clean(self, text: str) -> str:
        text = self._remove_control_chars(text)
        text = self._normalise_unicode(text)
        text = self._collapse_whitespace(text)
        text = self._remove_page_numbers(text)
        return text.strip()

    @staticmethod
    def _remove_control_chars(text: str) -> str:
        """Remove null bytes and non-printable ASCII control characters."""
        text = text.replace("\x00", "")
        # Keep \n \t but remove other C0 controls
        return re.sub(r"[\x01-\x08\x0b\x0c\x0e-\x1f\x7f]", "", text)

    @staticmethod
    def _normalise_unicode(text: str) -> str:
        return unicodedata.normalize("NFC", text)

    @staticmethod
    def _collapse_whitespace(text: str) -> str:
        # Collapse runs of spaces/tabs on a single line
        text = re.sub(r"[ \t]{2,}", " ", text)
        # Collapse more than 2 consecutive blank lines
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text

    @staticmethod
    def _remove_page_numbers(text: str) -> str:
        """Remove standalone page-number lines like '— 12 —' or 'Page 5'."""
        text = re.sub(r"(?m)^[\-–—]*\s*\d+\s*[\-–—]*$", "", text)
        text = re.sub(r"(?mi)^page\s+\d+(\s+of\s+\d+)?$", "", text)
        return text
