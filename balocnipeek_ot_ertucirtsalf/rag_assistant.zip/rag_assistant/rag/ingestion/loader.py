"""
rag/ingestion/loader.py
-----------------------
Loads documents from disk using Apache Tika as the primary extractor,
with pypdf and python-docx as fallbacks.

Supported formats: PDF, DOCX, DOC, TXT, and any of the 1000+ types Tika handles.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

# Tika — primary extractor (requires Java 7+)
try:
    from tika import parser as tika_parser
    TIKA_AVAILABLE = True
except ImportError:
    TIKA_AVAILABLE = False

# Fallback extractors
try:
    import pypdf
    PYPDF_AVAILABLE = True
except ImportError:
    PYPDF_AVAILABLE = False

try:
    from docx import Document as DocxDocument
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False


# ── Data model ───────────────────────────────────────────────────────────────

@dataclass
class RawDocument:
    """Represents extracted text + metadata from a single source file."""
    source: str                       # absolute path
    content: str                      # raw extracted text
    metadata: dict = field(default_factory=dict)


# ── Loader ───────────────────────────────────────────────────────────────────

class DocumentLoader:
    """
    Extracts text from files in a directory or from a list of file paths.

    Priority:
      1. Apache Tika   — handles 1000+ formats, incl. metadata
      2. pypdf         — PDF-only fallback
      3. python-docx   — DOCX-only fallback
      4. plain text    — .txt / .md files
    """

    SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".doc", ".txt", ".md"}

    def load_directory(self, directory: str) -> List[RawDocument]:
        """Recursively load all supported files from *directory*."""
        docs: List[RawDocument] = []
        for path in Path(directory).rglob("*"):
            if path.suffix.lower() in self.SUPPORTED_EXTENSIONS and path.is_file():
                doc = self._load_file(str(path))
                if doc:
                    docs.append(doc)
        return docs

    def load_files(self, file_paths: List[str]) -> List[RawDocument]:
        """Load a specific list of file paths."""
        docs: List[RawDocument] = []
        for fp in file_paths:
            doc = self._load_file(fp)
            if doc:
                docs.append(doc)
        return docs

    # ── internal ─────────────────────────────────────────────────────────────

    def _load_file(self, path: str) -> RawDocument | None:
        ext = Path(path).suffix.lower()
        try:
            if TIKA_AVAILABLE:
                return self._load_tika(path)
            elif ext == ".pdf" and PYPDF_AVAILABLE:
                return self._load_pypdf(path)
            elif ext in {".docx", ".doc"} and DOCX_AVAILABLE:
                return self._load_docx(path)
            elif ext in {".txt", ".md"}:
                return self._load_text(path)
            else:
                print(f"[loader] No extractor available for: {path}")
                return None
        except Exception as exc:
            print(f"[loader] Failed to load {path}: {exc}")
            return None

    def _load_tika(self, path: str) -> RawDocument:
        parsed = tika_parser.from_file(path)
        content = (parsed.get("content") or "").strip()
        metadata = parsed.get("metadata") or {}
        return RawDocument(source=path, content=content, metadata=metadata)

    def _load_pypdf(self, path: str) -> RawDocument:
        reader = pypdf.PdfReader(path)
        pages = [page.extract_text() or "" for page in reader.pages]
        content = "\n".join(pages).strip()
        return RawDocument(source=path, content=content,
                           metadata={"pages": len(reader.pages)})

    def _load_docx(self, path: str) -> RawDocument:
        doc = DocxDocument(path)
        content = "\n".join(p.text for p in doc.paragraphs if p.text).strip()
        return RawDocument(source=path, content=content)

    def _load_text(self, path: str) -> RawDocument:
        with open(path, encoding="utf-8", errors="ignore") as f:
            content = f.read().strip()
        return RawDocument(source=path, content=content)
