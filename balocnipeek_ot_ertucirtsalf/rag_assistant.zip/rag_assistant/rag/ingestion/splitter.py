"""
rag/ingestion/splitter.py
-------------------------
Splits cleaned documents into overlapping text chunks (the "chunking" step
before embedding).  Uses LangChain's RecursiveCharacterTextSplitter so the
splits respect sentence / paragraph boundaries where possible.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import List

from langchain.text_splitter import RecursiveCharacterTextSplitter

from rag.ingestion.loader import RawDocument


@dataclass
class Chunk:
    """One piece of a document ready for embedding."""
    text: str
    source: str
    chunk_index: int
    metadata: dict = field(default_factory=dict)


class DocumentSplitter:
    """
    Splits :class:`RawDocument` objects into :class:`Chunk` lists.

    Parameters
    ----------
    chunk_size    : target character length of each chunk
    chunk_overlap : number of characters shared between adjacent chunks
    """

    def __init__(
        self,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
    ):
        self.chunk_size = chunk_size or int(os.getenv("CHUNK_SIZE", 512))
        self.chunk_overlap = chunk_overlap or int(os.getenv("CHUNK_OVERLAP", 64))

        self._splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            separators=["\n\n", "\n", ". ", " ", ""],
        )

    def split(self, doc: RawDocument) -> List[Chunk]:
        """Split one document into chunks."""
        raw_chunks = self._splitter.split_text(doc.content)
        return [
            Chunk(
                text=text,
                source=doc.source,
                chunk_index=i,
                metadata={**doc.metadata, "source": doc.source, "chunk_index": i},
            )
            for i, text in enumerate(raw_chunks)
        ]

    def split_all(self, docs: List[RawDocument]) -> List[Chunk]:
        """Split a list of documents into a flat list of chunks."""
        chunks: List[Chunk] = []
        for doc in docs:
            chunks.extend(self.split(doc))
        print(f"[splitter] {len(docs)} docs → {len(chunks)} chunks "
              f"(size={self.chunk_size}, overlap={self.chunk_overlap})")
        return chunks
