"""
rag/retrieval/retriever.py
--------------------------
Given a user query, retrieves the most relevant text chunks from the
vector store using cosine similarity.

This module bridges the embedder and the vector store:
  query string → embedding → similarity search → ranked chunks
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import List

from rag.embeddings.embedder import Embedder
from rag.vectorstore.store import VectorStore


@dataclass
class RetrievedChunk:
    """A chunk returned by similarity search, with its relevance score."""
    text: str
    source: str
    chunk_index: int
    distance: float          # cosine distance — lower is more relevant
    metadata: dict


class Retriever:
    """
    Performs semantic retrieval over the vector store.

    Parameters
    ----------
    embedder    : :class:`Embedder` instance (shared with ingestion pipeline)
    store       : :class:`VectorStore` instance
    top_k       : number of chunks to return per query
    """

    def __init__(
        self,
        embedder: Embedder,
        store: VectorStore,
        top_k: int | None = None,
    ):
        self.embedder = embedder
        self.store = store
        self.top_k = top_k or int(os.getenv("TOP_K_RESULTS", 5))

    def retrieve(self, query: str, top_k: int | None = None) -> List[RetrievedChunk]:
        """
        Embed *query* and return the top-K most similar stored chunks.

        Parameters
        ----------
        query : natural-language question from the user
        top_k : override the default top_k for this call
        """
        k = top_k or self.top_k
        query_vec = self.embedder.embed_query(query)
        raw = self.store.query(query_vec, top_k=k)

        results: List[RetrievedChunk] = []
        for text, meta, dist in raw:
            results.append(RetrievedChunk(
                text=text,
                source=meta.get("source", "unknown"),
                chunk_index=int(meta.get("chunk_index", -1)),
                distance=dist,
                metadata=meta,
            ))
        return results

    def retrieve_as_context(self, query: str, top_k: int | None = None) -> str:
        """
        Convenience method: retrieve chunks and join them as a single
        context string to be injected into the LLM prompt.
        """
        chunks = self.retrieve(query, top_k=top_k)
        parts = []
        for i, c in enumerate(chunks, 1):
            parts.append(f"[Source {i}: {os.path.basename(c.source)}]\n{c.text}")
        return "\n\n---\n\n".join(parts)
