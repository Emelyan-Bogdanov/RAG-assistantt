# RAG Assistant

A production-structured Retrieval-Augmented Generation (RAG) system built with:
- **Apache Tika** — document text extraction (1000+ file types)
- **sentence-transformers/all-MiniLM-L6-v2** — chunk embeddings
- **ChromaDB** — persistent vector store
- **BERT** — optional professionality classifier
- **GPT-3.5-turbo** — answer generation
- **FastAPI** — HTTP API layer

---

## Project Structure

```
rag-assistant/
├── app/                        # API & chat interface
│   └── api.py                  # FastAPI routes
├── data/
│   ├── raw/                    # Drop your source documents here
│   └── processed/              # Cleaned text cache
├── rag/
│   ├── embeddings/
│   │   ├── embedder.py         # Sentence-transformer embeddings
│   │   └── models.py           # BERT professionality classifier
│   ├── generation/
│   │   ├── generator.py        # OpenAI GPT call
│   │   ├── history.py          # Conversational memory
│   │   └── prompt_builder.py   # Prompt assembly
│   ├── ingestion/
│   │   ├── loader.py           # Tika-based document loader
│   │   ├── cleaner.py          # Text normalisation
│   │   └── splitter.py         # Chunk splitting (LangChain)
│   ├── retrieval/
│   │   └── retriever.py        # Similarity search
│   ├── vectorstore/
│   │   └── store.py            # ChromaDB wrapper
│   └── pipeline.py             # Central orchestrator
├── scripts/
│   ├── ingest_docs.py          # CLI: index documents
│   └── query_test.py           # CLI: interactive REPL
├── tests/
│   └── test_pipeline.py
├── makestructure.py            # Scaffolding utility
├── .env                        # Environment variables (fill in & do NOT commit)
└── requirements.txt
```

---

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure environment
Edit `.env` and set `OPENAI_API_KEY` and other parameters.

### 3. Add documents
Place your PDF / DOCX / TXT files in `./data/raw/`.

### 4. Index documents
```bash
python scripts/ingest_docs.py
```

### 5. Ask questions — CLI
```bash
python scripts/query_test.py
```

### 6. Start the API server
```bash
uvicorn app.api:app --reload
# → http://localhost:8000/docs
```

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/health` | Liveness + chunk count |
| `POST` | `/ingest` | Index documents |
| `POST` | `/query` | Ask a question |
| `DELETE` | `/history` | Reset conversation |

---

## RAG Pipeline Flow

```
Documents → Loader (Tika) → Cleaner → Splitter → Embedder → ChromaDB
                                                                  ↓
User Question → Embedder → Retriever → PromptBuilder → GPT-3.5 → Answer
```

---

## Technologies

| Component | Technology |
|-----------|-----------|
| Text extraction | Apache Tika |
| Embeddings | sentence-transformers/all-MiniLM-L6-v2 |
| Vector DB | ChromaDB |
| LLM | GPT-3.5-turbo (OpenAI) |
| Text classifier | BERT (bert-base-uncased) |
| RAG framework | LangChain |
| API | FastAPI + Uvicorn |

---

*Developed during internship at Cabinet Vecteurs, Agadir — Ibrahim Id-wahman, 2026*
