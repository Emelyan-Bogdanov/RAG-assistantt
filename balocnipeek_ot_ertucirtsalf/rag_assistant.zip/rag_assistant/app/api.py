"""
app/api.py
----------
FastAPI application exposing the RAG pipeline via HTTP.

Endpoints
---------
  POST /ingest        — index documents from the data directory
  POST /query         — ask a question, get an answer
  DELETE /history     — clear the conversation history
  GET  /health        — liveness check
"""

from __future__ import annotations

import os
from typing import List, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

load_dotenv()

from rag.pipeline import RAGPipeline

app = FastAPI(
    title="RAG Assistant API",
    description="Retrieval-Augmented Generation chatbot backed by ChromaDB + OpenAI",
    version="1.0.0",
)

# Initialise the pipeline once at startup
_pipeline: RAGPipeline | None = None


def get_pipeline() -> RAGPipeline:
    global _pipeline
    if _pipeline is None:
        _pipeline = RAGPipeline()
    return _pipeline


# ── Request / Response models ────────────────────────────────────────────────

class IngestRequest(BaseModel):
    directory: Optional[str] = None          # defaults to ./data/raw
    file_paths: Optional[List[str]] = None   # ingest specific files


class IngestResponse(BaseModel):
    chunks_indexed: int
    message: str


class QueryRequest(BaseModel):
    question: str
    top_k: Optional[int] = None


class QueryResponse(BaseModel):
    question: str
    answer: str
    indexed_chunks: int


# ── Routes ───────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "indexed_chunks": get_pipeline().indexed_count}


@app.post("/ingest", response_model=IngestResponse)
def ingest(req: IngestRequest):
    pipe = get_pipeline()
    try:
        if req.file_paths:
            n = pipe.ingest_files(req.file_paths)
        else:
            n = pipe.ingest(req.directory)
        return IngestResponse(chunks_indexed=n, message=f"Indexed {n} chunks successfully.")
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/query", response_model=QueryResponse)
def query(req: QueryRequest):
    if not req.question.strip():
        raise HTTPException(status_code=400, detail="Question cannot be empty.")
    pipe = get_pipeline()
    try:
        answer = pipe.query(req.question, top_k=req.top_k)
        return QueryResponse(
            question=req.question,
            answer=answer,
            indexed_chunks=pipe.indexed_count,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.delete("/history")
def reset_history():
    get_pipeline().reset_history()
    return {"message": "Conversation history cleared."}


# ── Entry point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.api:app",
        host=os.getenv("APP_HOST", "0.0.0.0"),
        port=int(os.getenv("APP_PORT", 8000)),
        reload=os.getenv("DEBUG", "true").lower() == "true",
    )
