"""
scripts/query_test.py
---------------------
Interactive REPL for testing the RAG pipeline from the command line.

Usage
-----
    python scripts/query_test.py
    python scripts/query_test.py --top-k 3
"""

import sys
import os
import argparse

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from rag.pipeline import RAGPipeline


def main():
    parser = argparse.ArgumentParser(description="Interactive RAG query REPL")
    parser.add_argument("--top-k", type=int, default=5,
                        help="Number of chunks to retrieve per query")
    args = parser.parse_args()

    pipe = RAGPipeline()
    print(f"\nRAG Assistant ready — {pipe.indexed_count} chunks indexed.")
    print("Type your question and press Enter. Type 'exit' to quit, 'reset' to clear history.\n")

    while True:
        try:
            question = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break

        if not question:
            continue
        if question.lower() == "exit":
            print("Bye!")
            break
        if question.lower() == "reset":
            pipe.reset_history()
            print("[history cleared]\n")
            continue

        answer = pipe.query(question, top_k=args.top_k)
        print(f"\nAssistant: {answer}\n")


if __name__ == "__main__":
    main()
