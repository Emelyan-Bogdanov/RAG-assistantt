"""
scripts/ingest_docs.py
----------------------
Command-line script to index documents into the vector store.

Usage
-----
    python scripts/ingest_docs.py --dir ./data/raw
    python scripts/ingest_docs.py --files doc1.pdf doc2.docx
"""

import argparse
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from rag.pipeline import RAGPipeline


def main():
    parser = argparse.ArgumentParser(description="Ingest documents into the RAG vector store")
    parser.add_argument("--dir", type=str, default="./data/raw",
                        help="Directory to scan for documents (default: ./data/raw)")
    parser.add_argument("--files", nargs="+", type=str,
                        help="Specific file paths to ingest (overrides --dir)")
    args = parser.parse_args()

    pipe = RAGPipeline()

    if args.files:
        n = pipe.ingest_files(args.files)
    else:
        n = pipe.ingest(args.dir)

    print(f"\n✓ Done. {n} chunks indexed. Total in store: {pipe.indexed_count}")


if __name__ == "__main__":
    main()
