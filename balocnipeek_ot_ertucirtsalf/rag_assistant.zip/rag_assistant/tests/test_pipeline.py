"""
tests/test_pipeline.py
----------------------
Unit tests for the RAG pipeline components.
Run with: pytest tests/
"""

import pytest
from unittest.mock import MagicMock, patch
import numpy as np

from rag.ingestion.cleaner import TextCleaner
from rag.ingestion.splitter import DocumentSplitter
from rag.ingestion.loader import RawDocument
from rag.generation.history import ChatHistory


# ── TextCleaner ──────────────────────────────────────────────────────────────

class TestTextCleaner:
    def setup_method(self):
        self.cleaner = TextCleaner()

    def test_removes_page_numbers(self):
        text = "Some content\n— 12 —\nMore content"
        result = self.cleaner.clean(text)
        assert "12" not in result or "—" not in result

    def test_collapses_blank_lines(self):
        text = "Line 1\n\n\n\nLine 2"
        result = self.cleaner.clean(text)
        assert "\n\n\n" not in result

    def test_removes_control_chars(self):
        text = "Hello\x00World\x07!"
        result = self.cleaner.clean(text)
        assert "\x00" not in result
        assert "\x07" not in result

    def test_empty_string(self):
        assert self.cleaner.clean("") == ""


# ── DocumentSplitter ─────────────────────────────────────────────────────────

class TestDocumentSplitter:
    def setup_method(self):
        self.splitter = DocumentSplitter(chunk_size=100, chunk_overlap=10)

    def test_splits_long_doc(self):
        doc = RawDocument(source="test.txt", content="word " * 200)
        chunks = self.splitter.split(doc)
        assert len(chunks) > 1

    def test_preserves_source(self):
        doc = RawDocument(source="myfile.pdf", content="Short text.")
        chunks = self.splitter.split(doc)
        for c in chunks:
            assert c.source == "myfile.pdf"

    def test_chunk_indices(self):
        doc = RawDocument(source="test.txt", content="word " * 300)
        chunks = self.splitter.split(doc)
        for i, c in enumerate(chunks):
            assert c.chunk_index == i


# ── ChatHistory ───────────────────────────────────────────────────────────────

class TestChatHistory:
    def setup_method(self):
        self.history = ChatHistory(max_turns=3)

    def test_add_messages(self):
        self.history.add_user("Hello")
        self.history.add_assistant("Hi there")
        assert len(self.history) == 2

    def test_trim_overflow(self):
        for i in range(10):
            self.history.add_user(f"Q{i}")
            self.history.add_assistant(f"A{i}")
        assert len(self.history) <= 6  # max_turns * 2

    def test_openai_format(self):
        self.history.add_user("Test")
        msgs = self.history.to_openai_format()
        assert msgs[0]["role"] == "user"
        assert msgs[0]["content"] == "Test"

    def test_clear(self):
        self.history.add_user("Hello")
        self.history.clear()
        assert len(self.history) == 0
