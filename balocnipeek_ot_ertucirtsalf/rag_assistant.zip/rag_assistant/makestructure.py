"""
makestructure.py — Scaffolds the RAG Assistant project layout.
Run once to create all directories and empty placeholder files.
"""

import os

STRUCTURE = {
    "app": ["__init__.py", "api.py", "chat.py", "config.py"],
    "data/raw": [".gitkeep"],
    "data/processed": [".gitkeep"],
    "rag/embeddings": ["__init__.py", "embedder.py", "models.py"],
    "rag/generation": ["__init__.py", "generator.py", "history.py", "prompt_builder.py"],
    "rag/ingestion": ["__init__.py", "cleaner.py", "loader.py", "splitter.py"],
    "rag/retrieval": ["__init__.py", "chunker.py", "retriever.py", "similarity.py"],
    "rag/vectorstore": ["__init__.py", "store.py"],
    "rag": ["__init__.py", "pipeline.py"],
    "scripts": ["ingest_docs.py", "query_test.py"],
    "tests": ["__init__.py", "test_embeddings.py", "test_pipeline.py", "test_retrieval.py"],
}

ROOT = os.path.dirname(os.path.abspath(__file__))

for folder, files in STRUCTURE.items():
    dir_path = os.path.join(ROOT, folder)
    os.makedirs(dir_path, exist_ok=True)
    for fname in files:
        fpath = os.path.join(dir_path, fname)
        if not os.path.exists(fpath):
            open(fpath, "w").close()
            print(f"  created  {os.path.relpath(fpath, ROOT)}")
        else:
            print(f"  exists   {os.path.relpath(fpath, ROOT)}")

# Root-level files
for fname in [".env", "README.md", "requirements.txt"]:
    fpath = os.path.join(ROOT, fname)
    if not os.path.exists(fpath):
        open(fpath, "w").close()
        print(f"  created  {fname}")

print("\nDone — project structure is ready.")
